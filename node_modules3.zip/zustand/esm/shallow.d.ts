import { shallow } from './vanilla/shallow';
/**
 * @deprecated Use `import { shallow } from 'zustand/shallow'`
 */
declare const _default: typeof shallow;
export default _default;
export { shallow };
