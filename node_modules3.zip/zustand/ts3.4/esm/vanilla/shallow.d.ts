export declare function shallow<T>(objA: T, objB: T): boolean;
