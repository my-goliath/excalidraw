const set = require('regenerate')(0x1107F);
set.addRange(0x11000, 0x1104D).addRange(0x11052, 0x11075);
exports.characters = set;
