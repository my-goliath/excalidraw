const set = require('regenerate')();
set.addRange(0x2800, 0x28FF);
exports.characters = set;
