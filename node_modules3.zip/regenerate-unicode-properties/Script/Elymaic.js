const set = require('regenerate')();
set.addRange(0x10FE0, 0x10FF6);
exports.characters = set;
