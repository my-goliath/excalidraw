import * as JotaiRedux from 'jotai-redux';
/**
 * @deprecated use `jotai-redux` instead
 */
export declare const atomWithStore: typeof JotaiRedux.atomWithStore;
