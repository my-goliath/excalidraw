import type { Atom, SetStateAction, WritableAtom } from 'jotai';
import { RESET } from './constants';
type Read<Value> = Atom<Value>['read'];
export declare function atomWithDefault<Value>(getDefault: Read<Value | Promise<Value>>): WritableAtom<Value, SetStateAction<Value> | typeof RESET>;
export declare function atomWithDefault<Value>(getDefault: Read<Promise<Value>>): WritableAtom<Value, SetStateAction<Value> | typeof RESET>;
export declare function atomWithDefault<Value>(getDefault: Read<Value>): WritableAtom<Value, SetStateAction<Value> | typeof RESET>;
export {};
