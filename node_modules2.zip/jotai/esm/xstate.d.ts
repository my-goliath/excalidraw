export { RESTART } from 'jotai-xstate';
import * as JotaiXstate from 'jotai-xstate';
/**
 * @deprecated use `jotai-xstate` instead
 */
export declare const atomWithMachine: typeof JotaiXstate.atomWithMachine;
