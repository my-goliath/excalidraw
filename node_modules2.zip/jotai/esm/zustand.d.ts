import * as JotaiZustand from 'jotai-zustand';
/**
 * @deprecated use `jotai-zustand` instead
 */
export declare const atomWithStore: typeof JotaiZustand.atomWithStore;
