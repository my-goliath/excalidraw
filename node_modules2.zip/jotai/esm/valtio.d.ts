import * as JotaiValtio from 'jotai-valtio';
/**
 * @deprecated use `jotai-valtio` instead
 */
export declare const atomWithProxy: typeof JotaiValtio.atomWithProxy;
