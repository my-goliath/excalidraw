export declare const RESET: unique symbol;
