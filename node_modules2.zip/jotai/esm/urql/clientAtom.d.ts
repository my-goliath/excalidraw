export { clientAtom } from 'jotai-urql';
