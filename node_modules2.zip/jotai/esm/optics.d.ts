import * as JotaiOptics from 'jotai-optics';
/**
 * @deprecated use `jotai-optics` instead
 */
export declare const focusAtom: typeof JotaiOptics.focusAtom;
