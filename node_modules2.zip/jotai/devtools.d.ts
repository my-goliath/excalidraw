import * as JotaiDevtools from 'jotai-devtools';
/**
 * @deprecated use `jotai-devtools` instead.
 */
export declare const useAtomsDebugValue: typeof JotaiDevtools.useAtomsDebugValue;
/**
 * @deprecated use `jotai-devtools` instead.
 */
export declare const useAtomDevtools: typeof JotaiDevtools.useAtomDevtools;
/**
 * @deprecated use `jotai-devtools` instead.
 */
export declare const useAtomsSnapshot: typeof JotaiDevtools.useAtomsSnapshot;
/**
 * @deprecated use `jotai-devtools` instead.
 */
export declare const useGotoAtomsSnapshot: typeof JotaiDevtools.useGotoAtomsSnapshot;
/**
 * @deprecated use `jotai-devtools` instead.
 */
export declare const useAtomsDevtools: typeof JotaiDevtools.useAtomsDevtools;
