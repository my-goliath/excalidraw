export { clientAtom } from 'jotai-urql';
declare type Awaited<T> = T extends Promise<infer V> ? V : T;