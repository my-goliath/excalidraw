import * as JotaiImmer from 'jotai-immer';
/**
 * @deprecated use `jotai-immer` instead.
 */
export declare const atomWithImmer: typeof JotaiImmer.atomWithImmer;
/**
 * @deprecated use `jotai-immer` instead.
 */
export declare const useImmerAtom: typeof JotaiImmer.useImmerAtom;
/**
 * @deprecated use `jotai-immer` instead.
 */
export declare const withImmer: typeof JotaiImmer.withImmer;
declare type Awaited<T> = T extends Promise<infer V> ? V : T;