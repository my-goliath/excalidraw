import * as JotaiRedux from 'jotai-redux';
/**
 * @deprecated use `jotai-redux` instead
 */
export declare const atomWithStore: typeof JotaiRedux.atomWithStore;
declare type Awaited<T> = T extends Promise<infer V> ? V : T;