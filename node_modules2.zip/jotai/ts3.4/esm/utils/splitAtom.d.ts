import { Atom, PrimitiveAtom, WritableAtom } from 'jotai';
type SplitAtomAction<Item> = {
    type: 'remove';
    atom: PrimitiveAtom<Item>;
} | {
    type: 'insert';
    value: Item;
    before?: PrimitiveAtom<Item>;
} | {
    type: 'move';
    atom: PrimitiveAtom<Item>;
    before?: PrimitiveAtom<Item>;
};
type DeprecatedAtomToRemove<Item> = PrimitiveAtom<Item>;
export declare function splitAtom<Item, Key>(arrAtom: WritableAtom<Item[], Item[]>, keyExtractor?: (item: Item) => Key): WritableAtom<PrimitiveAtom<Item>[], SplitAtomAction<Item> | DeprecatedAtomToRemove<Item>>;
export declare function splitAtom<Item, Key>(arrAtom: Atom<Item[]>, keyExtractor?: (item: Item) => Key): Atom<Atom<Item>[]>;
export {};
declare type Awaited<T> = T extends Promise<infer V> ? V : T;