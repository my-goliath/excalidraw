declare const SUSPENSE_PROMISE: unique symbol;
interface SuspensePromiseExtra {
    b: Promise<unknown>;
    o: Promise<void>;
    c: (() => void) | null;
}
export type SuspensePromise = Promise<void> & {
    [SUSPENSE_PROMISE]: SuspensePromiseExtra;
};
export declare const isSuspensePromise: (promise: Promise<void>) => promise is SuspensePromise;
export declare const isSuspensePromiseAlreadyCancelled: (suspensePromise: SuspensePromise) => boolean;
export declare const cancelSuspensePromise: (suspensePromise: SuspensePromise) => void;
export declare const isEqualSuspensePromise: (oldSuspensePromise: SuspensePromise, newSuspensePromise: SuspensePromise) => boolean;
export declare const createSuspensePromise: (basePromise: Promise<unknown>, promise: Promise<void>) => SuspensePromise;
export declare const copySuspensePromise: (suspensePromise: SuspensePromise) => SuspensePromise;
export declare const registerPromiseAbort: (basePromise: Promise<unknown>, abort: () => void) => void;
export {};
declare type Awaited<T> = T extends Promise<infer V> ? V : T;