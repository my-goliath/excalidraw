wsn_constraints = {
  "fixedNodeConstraint": [
    {
      "nodeId": "86f48f58-145d-92cc-0d33-aaf639984733",
      "position": {
        "x": 399,
        "y": 139
      }
    },
    {
      "nodeId": "f91d914e-6ab7-92cf-b16d-b9a7661e0044",
      "position": {
        "x": 857,
        "y": 340
      }
    },
    {
      "nodeId": "33f80abd-028e-ad1c-068b-33d5b40d9a93",
      "position": {
        "x": 1068,
        "y": 288
      }
    },
    {
      "nodeId": "2b855d36-0c89-996d-9281-ea54f711cc8e",
      "position": {
        "x": 520,
        "y": 518
      }
    },
    {
      "nodeId": "0ddcc98c-7b7c-ac2e-2207-081c5ffc9921",
      "position": {
        "x": 533,
        "y": -37
      }
    },
    {
      "nodeId": "e53126c9-70fe-ca8a-3b85-bab123a93d70",
      "position": {
        "x": 816,
        "y": 280
      }
    },
    {
      "nodeId": "4ca3044f-9b82-020b-e1cb-bbb45e4b0088",
      "position": {
        "x": 630,
        "y": 205
      }
    },
    {
      "nodeId": "bc0420e3-9b6e-4c97-74c6-61278dbc18d4",
      "position": {
        "x": 507,
        "y": 407
      }
    },
    {
      "nodeId": "a97f8f48-6652-7e09-8eda-2d87eae7d20b",
      "position": {
        "x": 323,
        "y": 330
      }
    },
    {
      "nodeId": "889eedb3-8cb8-b906-8beb-904cd499c4f6",
      "position": {
        "x": 892,
        "y": -55
      }
    },
    {
      "nodeId": "bd77a77c-4627-ad77-1c5a-2c390ba21959",
      "position": {
        "x": 1114,
        "y": 570
      }
    },
    {
      "nodeId": "ffbd69bf-481f-faa8-73db-1489f3175b75",
      "position": {
        "x": 666,
        "y": 533
      }
    },
    {
      "nodeId": "5fdc6150-63bb-18e8-1f03-33bb8d6b7529",
      "position": {
        "x": 726,
        "y": 670
      }
    },
    {
      "nodeId": "b386ca2b-81a7-e365-4706-f955f13db03f",
      "position": {
        "x": 721,
        "y": -36
      }
    }
  ]
}