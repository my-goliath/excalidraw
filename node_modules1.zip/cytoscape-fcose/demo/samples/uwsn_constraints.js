uwsn_constraints = {
  "fixedNodeConstraint": [
    {
      "nodeId": "nwtN_91cff953-5f55-4626-96fa-e2f675e13e54",
      "position": {
        "x": -650,
        "y": -230
      }
    },
    {
      "nodeId": "nwtN_b20cc3f4-dc9c-4031-ac79-df665d4c53cd",
      "position": {
        "x": 0,
        "y": -230
      }
    },
    {
      "nodeId": "nwtN_5d6f7198-03e4-48e5-9004-919221f87e66",
      "position": {
        "x": 650,
        "y": -230
      }
    }
  ],
  "alignmentConstraint": {
    "vertical": [
      [
        "nwtN_91cff953-5f55-4626-96fa-e2f675e13e54",
        "nwtN_7e09bf9e-a4da-4618-baba-60a2b3a0b134"
      ],
      [
        "nwtN_b20cc3f4-dc9c-4031-ac79-df665d4c53cd",
        "661498c7-ace9-bd34-0289-7c9931d3e1ba"
      ],
      [
        "nwtN_5d6f7198-03e4-48e5-9004-919221f87e66",
        "aeee80bf-8280-f4ec-c1f3-26f3a7a0651c"
      ]
    ]
  },
  "relativePlacementConstraint": [
    {
      "top": "nwtN_7e09bf9e-a4da-4618-baba-60a2b3a0b134",
      "bottom": "nwtN_be627c29-b885-460c-bf92-8f9bb7b8c8c5",
      "gap": 100
    },
    {
      "top": "nwtN_7e09bf9e-a4da-4618-baba-60a2b3a0b134",
      "bottom": "nwtN_64abed47-d1b1-474c-b944-b9ad6354c086",
      "gap": 100
    },
    {
      "top": "661498c7-ace9-bd34-0289-7c9931d3e1ba",
      "bottom": "nwtN_0185dada-235a-4b51-bce7-e8bd3b8ee661",
      "gap": 100
    },
    {
      "top": "661498c7-ace9-bd34-0289-7c9931d3e1ba",
      "bottom": "nwtN_273f6927-f05a-425b-aa2b-92de2be06bd9",
      "gap": 100
    },
    {
      "top": "aeee80bf-8280-f4ec-c1f3-26f3a7a0651c",
      "bottom": "5c108d5c-88e4-7b97-95a8-67238c33d283",
      "gap": 100
    },
    {
      "top": "aeee80bf-8280-f4ec-c1f3-26f3a7a0651c",
      "bottom": "3ea6020e-8918-8abf-a8e5-62427070f84f",
      "gap": 100
    },
    {
      "top": "nwtN_5d6f7198-03e4-48e5-9004-919221f87e66",
      "bottom": "aeee80bf-8280-f4ec-c1f3-26f3a7a0651c",
      "gap": 250
    },
    {
      "top": "nwtN_b20cc3f4-dc9c-4031-ac79-df665d4c53cd",
      "bottom": "661498c7-ace9-bd34-0289-7c9931d3e1ba",
      "gap": 250
    },
    {
      "top": "nwtN_91cff953-5f55-4626-96fa-e2f675e13e54",
      "bottom": "nwtN_7e09bf9e-a4da-4618-baba-60a2b3a0b134",
      "gap": 250
    }
  ]
}