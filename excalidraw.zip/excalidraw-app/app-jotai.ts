import { unstable_createStore } from "jotai";

export const appJotaiStore = unstable_createStore();
